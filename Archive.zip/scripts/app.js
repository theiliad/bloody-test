angular.module('dangerZone', ['ngMaterial', 'ui.router', 'ngAnimate', 'md.data.table'])
       .controller('dangerZoneCtrl', function ($scope) {
});