angular.module('dangerZone', ['ngMaterial', 'ui.router', 'ngAnimate', 'md.data.table', 'anim-in-out'])
       .controller('dangerZoneCtrl', function ($scope) {
});